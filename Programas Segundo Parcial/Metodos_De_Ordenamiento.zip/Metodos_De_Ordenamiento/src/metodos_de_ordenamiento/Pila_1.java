/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package metodos_de_ordenamiento;

/**
 *
 * @author Raul
 */
public class Pila_1 {
    private Nodo_1 top; //último nodo que se ha incluido
private int tamanio; //el número de elementos en la pila
public Pila_1() { //Constructor
top = null; //No hay elementos
this.tamanio = 0;// el tamaño es cero
}
public boolean isEmpty() {//informa si la pila esta vacía
return top == null; }
//Informa el número de elementos en la pila
public int size() { return this.tamanio; }
public Nodo_1 top() { //entrega el Nodo en el tope de pila
if (isEmpty()) {
return null;
} else { return top; }
}
public Nodo_1 pop(Nodo_1 i) { //entrega el último nodo de la pila
System.out.println("Inicio del método POP ");
System.out.println("Valor de i: "+ i.getElemento());
Nodo_1 s= new Nodo_1(0,null);
//recorre la pila hasta el tope de pila
while(i.getSiguiente()!=null){
s=i.getSiguiente();
if(s.getSiguiente()==null){
Nodo_1 aux=s.getSiguiente();
System.out.println("Valor conseguido:"+ s.getElemento());
i.setSiguiente(null);
top=i;
return top; }
else{ i=s; }
}
this.tamanio--; //disminuye el tamaño de la pila
top=i; //Actualiza el tope de pila
return top;
}
public Nodo_1 push(Nodo_1 i,Nodo_1 nv) { //Inserta nodos en la pila
if (i.getSiguiente()==null){
i.setSiguiente(nv);
System.out.println("Valor insertado "+nv.getElemento());
top=i;
return top;
}
else{
Nodo_1 s=visitarPila(i);
if (s.getSiguiente()==null){
System.out.println("Valor insertado "+ nv.getElemento());
s.setSiguiente(nv);
top=s.getSiguiente();
this.tamanio++;
return top;
}
}
return top; }

    private Nodo_1 visitarPila(Nodo_1 i) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    
}

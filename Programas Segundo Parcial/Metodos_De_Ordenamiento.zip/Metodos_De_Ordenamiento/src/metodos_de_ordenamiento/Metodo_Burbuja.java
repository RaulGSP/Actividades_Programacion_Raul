/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package metodos_de_ordenamiento;

import java.util.Arrays;
import java.util.Random;

/**
 *
 * @author eq12
 */
public class Metodo_Burbuja {
    public static void main(String[] args) {
        int [] numeros= numerosaleatorios(10);
        System.out.println("numeros antes del ordenamiento"+Arrays.toString(numeros));
        for(int i=0;i<numeros.length-1;i++){
            int menor=i;
            for(int j=i+1;j<numeros.length;j++){
                if(numeros[j]<numeros[menor]){
                    menor=j;   
                }
            }
            int temp=numeros[i];
            numeros[i]=numeros[menor];
            numeros[menor]=temp;
        }
        System.out.println("Despues del ordenamiento: "+Arrays.toString(numeros));
        
    }
     

    private static int[] numerosaleatorios(int tamano) {
        int[]numeros =new int[tamano];
        Random random = new Random();
        for(int i=0;i<numeros.length;i++){
            numeros[i]=random.nextInt(100);
        }
        return numeros; 
    }
}

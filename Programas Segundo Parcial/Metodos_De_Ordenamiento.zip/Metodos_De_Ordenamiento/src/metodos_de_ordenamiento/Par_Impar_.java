/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package metodos_de_ordenamiento;

/**
 *
 * @author Raul
 */
public class Par_Impar_ {
    public static void main(String[] args) {
        int SumaDeNumerosPares= 0;
        int SumaDeNumerosImpares =0;
        int cuentapar= 0;
        int cuentaimpar=0;
        for(int i=1; i<=10; i++){
            if (i% 2==0){
               
                cuentapar ++;
                SumaDeNumerosPares +=i;
                if(cuentapar ==3){
                    break;
                }
            }else{

                cuentaimpar ++;
                SumaDeNumerosImpares +=i;
                if(cuentaimpar==3){
                    break;
                }
            }
        }
        System.out.println("La suma de los tres primeros nueros pares es:" + SumaDeNumerosPares);
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package metodos_de_ordenamiento;

import static java.lang.Math.random;
import java.util.Random;

/**
 *
 * @author eq12
 */
public class Random_Array {
    public static void main(String[] args) {
       int N = 10;
        int [] numeros = new int[N]; 
        Random random = new Random (); 
        for (int i=0; i<N; i++){
            numeros[i]= random.nextInt(100)+1;
            
        }
        for (int i=0; i<N;i++){
            System.out.println(numeros[i]+"");
        }
        System.out.println();
        
    }
    
}

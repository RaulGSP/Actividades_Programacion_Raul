/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package metodos_de_ordenamiento;

/**
 *
 * @author Raul
 */
public class Nodo_1 {
    private int elemento;
private Nodo_1 siguiente;
public Nodo_1(int elemento, Nodo_1 siguiente) {
this.elemento = elemento;
this.siguiente = siguiente;
}

public int getElemento() { return elemento; }
public void setElemento(int elemento) { this.elemento = elemento; }
public Nodo_1 getSiguiente() { return siguiente; }
public void setSiguiente(Nodo_1 siguiente) { this.siguiente = siguiente; }
@Override
public String toString() { return elemento + "\n"; }
}

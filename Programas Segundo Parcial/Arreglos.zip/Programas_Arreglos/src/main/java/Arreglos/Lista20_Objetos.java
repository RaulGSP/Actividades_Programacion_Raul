/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arreglos;

/**
 *
 * @author Raul
 */
public class Lista20_Objetos {
    public static void main(String[] args) {
        int[] numeros = new int[20]; 
        numeros[0]=1; 
        numeros[1]=2;
        numeros[2]=3;
        numeros[3]=4; 
        numeros[4]=5;
        numeros[5]=6;
        numeros[6]=7; 
        numeros[7]=8; 
        numeros[8]=9; 
        numeros[9]=10; 
        numeros[10]=11; 
        numeros[11]=12; 
        numeros[12]=13; 
        numeros[13]=14; 
        numeros[14]=15; 
        numeros[15]=16; 
        numeros[16]=17; 
        numeros[17]=18; 
        numeros[18]=19; 
        numeros[19]=20; 
        System.out.println("Los elementos almacenados son ");
        for(int i=0; i<numeros.length; i++){
            System.out.println((i+1) + ":" + numeros[i]);
        }

    }
}

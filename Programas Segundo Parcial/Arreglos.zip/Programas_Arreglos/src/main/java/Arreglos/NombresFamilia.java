/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arreglos;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Raul
 */
public class NombresFamilia {
    public static void main(String[] args) {
        List<String> listanombres= new ArrayList<String>();
        listanombres.add("Esther");
        listanombres.add("Manuel");
        listanombres.add("Sebastian");
        listanombres.add("Raul");
        System.out.println(listanombres);
    }
 
}

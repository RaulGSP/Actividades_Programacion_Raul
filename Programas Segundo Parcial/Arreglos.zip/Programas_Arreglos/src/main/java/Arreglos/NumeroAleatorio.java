/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arreglos;

import java.util.Random;


/**
 *
 * @author Raul
 */
public class NumeroAleatorio {
    public static void main(String[] args) {
        int num = 10; 
        int [] numeros = new int[num];
        Random random = new Random (); 
        for(int i= 0; i<num; i++){
            numeros[i]=random.nextInt(15)+1;
        }
for(int i=0; i<num; i++){
    System.out.println(numeros[i]+"");
}
    }
}

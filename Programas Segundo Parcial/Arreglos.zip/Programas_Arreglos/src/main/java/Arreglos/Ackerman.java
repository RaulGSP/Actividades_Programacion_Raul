/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arreglos;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class Ackerman {
   static Scanner inicio = new Scanner (System.in);
   static int Ackerman(int m, int n){
       if(m == 0)
       return n+1;
       else if (n == 0)
           return Ackerman(m-1,1);
       else
           return Ackerman(m-1, Ackerman(m,n-1));
   }
    
   public static void main ( String [] argas){
       int m,n;
       System.out.println("Ingresar el primer valor");
       m = inicio.nextInt();
       System.out.println("Ingresar el segundo valor");
       n = inicio.nextInt();
       System.out.println("El valor de Ackerman es:" + Ackerman(m,n));
   }
}
